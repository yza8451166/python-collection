#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/6 14:49
# @Author  : xc
# @Site    : 
# @File    : rangetest.py
# @Software: PyCharm


# 1 2  3 4 5
# for i in range(1,6):
#     print(i)

# 1 3 5 7 9
# for i in range(1,10,2):
#     print(i)


# 0 1 2 3 4 5 6  7 8 9
# for i in range(10):
#     print(i)
#
# for i in range(4,-1,-1):
#     print(i)
