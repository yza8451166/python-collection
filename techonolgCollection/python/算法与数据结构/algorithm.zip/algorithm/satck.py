#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/5/23 16:15
# @Author  : xc
# @Site    : 
# @File    : satck.py
# @Software: PyCharm


stack=[]
stack.append(1)
stack.append(2)
print(stack.pop())
print(stack[-1])



def check_kuohao(s):
    stack=[]


